# Deploy Python app on heroku cloud platform
<img src="https://github.com/aipythonIndia/Deploy-python-on-heroku/blob/main/Deploy-python-app.png" width="540">

 Deploying python script on heroku - to get vaccine notification on telegram<br>
 
 🤝 Connect and follow aipython<br>
Website  : https://www.aipython.in<br>
facebook (Page) : https://www.facebook.com/aipythonIndia<br>
Facebook (Group): https://www.facebook.com/groups/aipython<br>
Instagram: https://www.instagram.com/aipython_india<br>
Twitter  : https://twitter.com/aipython_India<br>
LinkedIn : https://www.linkedin.com/in/aipythonIndia/<br>
